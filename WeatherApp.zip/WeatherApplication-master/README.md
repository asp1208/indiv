# WeatherApplication
A basic weather application.

The aim is to make use of different components and libraries and frameworks in Android.
All different components are in their respective branch.

Tech/Language/Libraries/Framework used or to be used - 

1.Koltin as language -  In Use

2.Retrofit for networking - Implemented

3.Rxjava2 for computation and network scheduling - Implemented

4.Dagger2 for dependency injection - Implemented

5.Unit Testing - In progress

6.Expresso Testing - In Progress

7.MVP as architecture - Followed

8.Timber - In use

9.Google Architecture Components - In Progress
