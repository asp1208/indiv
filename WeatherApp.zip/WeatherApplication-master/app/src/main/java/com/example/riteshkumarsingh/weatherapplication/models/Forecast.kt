package com.example.riteshkumarsingh.gojek.data.models

data class Forecast(
	val forecastday: List<ForecastdayItem?>? = null
)
