package com.example.riteshkumarsingh.gojek.data.models

data class WeatherForecast(
	val current: Current? = null,
	val location: Location? = null,
	val forecast: Forecast? = null
)
